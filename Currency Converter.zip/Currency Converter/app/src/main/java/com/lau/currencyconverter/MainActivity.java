package com.lau.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

  Spinner spinner1,spinner2;
  EditText txt1;
  Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txt1=findViewById(R.id.txtamount);
        spinner1=findViewById(R.id.spinner1);
        spinner2=findViewById(R.id.spinner2);
        b1=findViewById(R.id.button);

        String[] from={"USD","LBP"};
        ArrayAdapter ad=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,from);
        spinner1.setAdapter(ad);

        String[] to={"LBP","USD"};
        ArrayAdapter ad2=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,to);
        spinner2.setAdapter(ad2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double converted;
                Double amount=Double.parseDouble(txt1.getText().toString());

                if(spinner1.getSelectedItem().toString()=="USD"&&spinner2.getSelectedItem().toString()=="LBP"){

                    converted =amount*15000.0;
                    Toast.makeText(getApplicationContext(), converted .toString(), Toast.LENGTH_LONG).show();
                }
                else if(spinner1.getSelectedItem().toString()=="LBP"&&spinner2.getSelectedItem().toString()=="USD"){

                    converted =amount/15000.0;
                    Toast.makeText(getApplicationContext(), converted.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    }







